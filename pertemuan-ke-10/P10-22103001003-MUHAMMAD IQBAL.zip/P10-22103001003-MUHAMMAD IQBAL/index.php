<?php
include_once 'App\init.php';
new App\Buah\Apel();
echo "<br/>";
new App\Buah\Jeruk();
echo "<br/>";
new App\Buah\Mangga();
echo "<br/>";
new App\Sayur\Apel();
echo "<br/>";
new App\Sayur\Jeruk();
echo "<br/>";
new App\Sayur\Mangga();
// Instantiating MagicMethod
$obj = new Apel();
$obj->hello("Magic" , "Method")