<?php

namespace App\Buah;

class Mangga
{
    public $warna;
    public function __construct($warna = "hijau")
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}
class Pahit extends Jeruk {
    public $rasa;
    function __construct($warna,$rasa = "pahit"){
        parent::__construct($warna);
        $this->rasa = $rasa;
    }
        // method untuk getter
    function getData(){
        return parent::getData() . " sangat {$this->rasa} rasanya <br/>";
    }
}