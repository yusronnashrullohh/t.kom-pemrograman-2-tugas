<?php

namespace App\Buah;

//Final keyword digunakan untuk mencegah sebuah class diwariskan atau inheritance
final class Apel
{
public $warna

//Final keyword digunakan untuk mencegah child class mengganti nilai property constant
final public const X = "bentuk";

//Final keyword digunakan untuk mencegah sebuah method yang diwariskan diganti atau overriding
final public function __construct($warna = "merah")
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
//magic method __call()
    function __call($name , $asal){
        echo "Name of method =>" . $name."\n";
        echo "Asal buah ini\n";
        print_r($asal);
    }
//magic method __tostring()
    public function __toString() {
        return $this->warna;
    }
}

namespace App\Buah;
class Manis extends Apel {
    public $rasa;
    function __construct($warna,$rasa = "enak"){
        parent::__construct($warna);
        $this->rasa = $rasa;
    }
 // method untuk getter
    function getData(){
        return parent::getData() . " sangat {$this->rasa} rasanya <br/>";
    }
}

 

 
