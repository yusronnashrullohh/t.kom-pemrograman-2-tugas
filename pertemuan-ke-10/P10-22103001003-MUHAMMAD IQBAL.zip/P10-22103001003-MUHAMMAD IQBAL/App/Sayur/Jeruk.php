<?php

namespace App\Sayur;

class Jeruk
{
    public $warna;
    public function __construct($warna = "oren")
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}
class Asem extends Jeruk {
    public $rasa;
    function __construct($warna,$rasa = "asem"){
        parent::__construct($warna);
        $this->rasa = $rasa;
    }
        // method untuk getter
    function getData(){
        return parent::getData() . " sangat {$this->rasa} rasanya <br/>";
    }
}