<?php

namespace App\Sayur;

class Apel
{
    public $warna;
    public function __construct($warna = "merah")
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}

class Manis extends Apel {
    public $rasa;
    function __construct($warna,$rasa = "enak"){
        parent::__construct($warna);
        $this->rasa = $rasa;
    }
        // method untuk getter
    function getData(){
        return parent::getData() . " sangat {$this->rasa} rasanya <br/>";
    }
}