<?php 
namespace Buah;

class Jeruk {
    private $warna;
    private $rasa;

    public function __construct($warna, $rasa) {
        $this->warna = $warna;
        $this->rasa = $rasa;
    }

    public function kupas() {
        echo "Mengupas jeruk " . $this->warna . " dengan rasa " . $this->rasa;
    }

    public function __call($name, $arguments) {
        echo "Method $name tidak ditemukan pada kelas Jeruk";
    }

    public function __toString() {
        return "Ini adalah objek Jeruk";
    }
}

?>