<?php 
namespace Buah;

class Apel {
    private $warna;
    private $rasa;

    public function __construct($warna, $rasa) {
        $this->warna = $warna;
        $this->rasa = $rasa;
    }

    public function makan() {
        echo "Menggigit apel " . $this->warna . " dengan rasa " . $this->rasa;
    }

    final public function getInfo() {
        return "Ini adalah apel " . $this->warna . " dengan rasa " . $this->rasa;
    }

    public function __call($name, $arguments) {
        echo "Method $name tidak ditemukan pada kelas Apel";
    }

    public function __toString() {
        return "Ini adalah objek Apel";
    }
}

?>