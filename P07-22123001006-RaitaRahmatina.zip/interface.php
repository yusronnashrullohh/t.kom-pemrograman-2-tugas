<?php
interface JenisApel{
    public function getInfoApel(); 
}
class Apel
{
    private $asal, $penjual, $rasa, $harga;
    public function __construct($asal = 0,$penjual = 0, $rasa = 0, $harga = 0){
        $this->asal = $asal;
        $this->penjual = $penjual;
        $this->rasa = $rasa;
        $this->harga = $harga;
    }

    public function setasal($asal){
    $this->asal = $asal;}
    public function getAsal(){
       return $this->asal;}

       public function setPenjual($penjual){
        $this->pembuat = $penjual;}
        public function getPenjual(){
           return $this->penjual;}
              
           public function rasa(){
            return $this->rasa;
           }
                    function getInfo(){
                        $str = "{$this->asal} maker {$this->getPenjual()} from {$this->rasa()} (Rp. {$this->harga})";
                        return $str;
                    }
}

class Manalagi extends Apel  implements JenisApel {
    public $merek;
    public function __construct($asal = 0, $penjual = 0, $rasa = 0, $harga = 0, $merek = 0)
        parent::__construct($asal, $penjual, $rasa, $harga);
        $this->merek = $merek;
    }
    public function getInfoApel(){
        $str = "Apel Manalagi : " . parent::getInfo() . " brand {$this->merek}." ;
        return $str;
    }
}

class Anna extends Apel implements JenisApel {
    public $brand;
    public function __construct($asal = 0,$penjual = 0, $rasa = 0, $harga = 0, $brand = 0){
        parent::__construct($asal, $penjual, $rasa, $harga);
        $this->brand = $brand;
    }
    public function getInfoApel(){
        $str = "Apel Anna : " . parent::getInfo() . " brand {$this->brand}." ;
        return $str;
    }   
}
class JenisInfoApel{
    public $daftarApel = array();
    public function tambahkanApel(Apel $apel){
        $this->daftarApel[] = $apel;
    }

    Public function jenis(){
        $str = "Daftar Apel :  <br/>";
        foreach ($this->daftarApel as $p){
            $str .= "- {$p->getInfoApel()} <br/>";
        } 
        return $str;
    }
}
$apel1 = new Manalagi("Malang", "Petani Malang", "Sedikit Masam", "6000", "Garansin");
$apel2 = new Anna("Batu Malang", "Petani Batu Malang", "Asam Manis","12.000","Klik Indomaret");

$jenisApel = new JenisInfoApel();
$jenisApel->tambahkanApel($apel1);
$jenisApel->tambahkanApel($apel2);

echo $jenisApel->jenis();