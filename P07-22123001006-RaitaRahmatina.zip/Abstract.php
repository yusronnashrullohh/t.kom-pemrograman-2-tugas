<?php

abstract Class Produk {
    private $merek, $asal, $warna, $harga, $diskon = 0;
    public function __construct($merek = "merek", $asal = "asal",
    $warna = "warna", $harga = 0, $diskon = 0){
        $this->merek = $merek;
        $this->asal = $asal;
        $this->warna = $warna;
        $this->harga = $harga;
        $this->diskon = $diskon;
    }
    public function setMerek($merek){
        $this->merek = $merek;
    }
    public function getMerek(){
        return $this->merek;
    }

    public function setAsal($asal){
        $this->asal = $asal;
    }
    public function getAsal(){
        return $this->asal;
    }

    public function setWarna($warna){
        $this->warna = $warna;
    }
    public function getWarna(){
        return $this->warna;
    }

    public function setHarga($harga){
        $this->harga = $harga;
    }
    public function getHarga(){
        return $this->harga;
    }

    public function setDiskon($diskon){
        $this->diskon = $diskon;
    }
    public function getDiskon(){
        return $this->diskon;
    }

    public function getLabel(){
        return "$this->merek, $this->asal";
    }

    abstract public function getInfoProduk();
    public function getInfo(){
        $str = "{$this->merek} | {$this->getLabel()} (Rp. {$this->harga})";
        return $str;
    }
} 

class AC extends Produk{
    public $jmlhKwh;

    public function __construct($merek = "merek", $asal = "asal",
    $warna = "warna", $harga = 0, $diskon = 0, $jmlhKwh = 0){
        parent::__construct($merek, $asal, $warna, $harga, $diskon);
        $this->jmlhKwh = $jmlhKwh;
    }

    public function getInfoProduk() {
        $str = "AC :" . $this->getInfo() . "-
    {$this->jmlhKwh} Kwh.";
    return $str;
    }
}

class Kipas extends Produk{
    public $jmlhWatt;

    public function __construct($merek = "merek", $asal = "asal",
    $warna = "warna", $harga = 0, $diskon = 0, $jmlhWatt = 0){
        parent::__construct($merek, $asal, $warna, $harga, $diskon);
        $this->jmlhWatt = $jmlhWatt;
    }

    public function getInfoProduk() {
        $str = "Kipas : " . $this->getInfo() . "- {$this->jmlhWatt} kW.";
    
    return $str;
    }
}

class CetakInfoProduk{
    public $daftarProduk = array();

    public function tambahProduk(Produk $produk){
        $this->daftarProduk[] = $produk;
    }
    public function cetak(){
        $str = "DAFTAR PRODUK : <br>";
        foreach($this->daftarProduk as $p){
            $str .= "- {$p->getInfoProduk()} <br>";
        }
        return $str;
    }
}
$produk1 = new AC("Daikin", "Panasonic", "Maspion", 5000000, 25000);
$produk2 = new Kipas("Cosmos", "Advance", "Miyako", 200000, 10000);

$cetakProduk = new CetakInfoProduk();
$cetakProduk->tambahProduk($produk1);
$cetakProduk->tambahProduk($produk2);
echo $cetakProduk->cetak();
// echo $produk1->getInfoProduk();
// echo "<br>";
// echo $produk2->getInfoProduk();