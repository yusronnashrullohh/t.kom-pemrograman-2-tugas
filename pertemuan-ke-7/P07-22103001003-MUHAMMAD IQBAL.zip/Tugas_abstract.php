<?php

abstract class Elektrunik
{
    private $sistemOperasi, $pembuat, $asal, $harga;
    public function __construct($sistemOperasi = 0,$pembuat = 0, $asal = 0, $harga = 0){
        $this->sistemOperasi = $sistemOperasi;
        $this->pembuat = $pembuat;
        $this->asal = $asal;
        $this->harga = $harga;
    }

    public function setSistemOperasi($sistemOperasi){
    $this->sistemOperasi = $sistemOperasi;}
    public function getSistemOperasi(){
       return $this->sistemOperasi;}

       public function setPembuat($pembuat){
        $this->pembuat = $pembuat;}
        public function getPembuat(){
           return $this->pembuat;}
              
           public function asal(){
            return $this->asal;
           }
                    abstract function getInfoElektrunik();
                    function getInfo(){
                        $str = "{$this->sistemOperasi} maker {$this->getPembuat()} from {$this->asal()} (Rp. {$this->harga})";
                        return $str;
                    }
}

class Handphone extends Elektrunik {
    public $merek;
    public function __construct($judul = 0,$penulis = 0, $penerbit = 0, $harga = 0, $merek = 0){
        parent::__construct($judul, $penulis, $penerbit, $harga);
        $this->merek = $merek;
    }
    public function getInfoElektrunik(){
        $str = "handphone : " . parent::getInfo() . " brand {$this->merek}." ;
        return $str;
    }
}

class Laptop extends Elektrunik {
    public $brand;
    public function __construct($judul = 0,$penulis = 0, $penerbit = 0, $harga = 0, $brand = 0){
        parent::__construct($judul, $penulis, $penerbit, $harga);
        $this->brand = $brand;
    }
    public function getInfoElektrunik(){
        $str = "laptop : " . parent::getInfo() . " brand {$this->brand}." ;
        return $str;
    }   
}

$elektrunik1 = new Handphone("IOS", "Steven Jobs", "Amerika", "18.000.000", "Apple" );
$elektrunik2 = new Laptop("Windows", "Bill Gates", "Inggris","12.000.000","Asus");
echo $elektrunik1->getInfoElektrunik();
echo "<br/>";
echo $elektrunik2->getInfoElektrunik();