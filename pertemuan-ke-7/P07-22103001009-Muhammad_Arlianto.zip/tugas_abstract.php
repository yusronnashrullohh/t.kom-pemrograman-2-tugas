<?php

abstract class Handphone{
    //properties
    private $merk, $version, $ukuranLayar, $harga  = 0;

    public function __construct($merk, $version, $ukuranLayar, $harga = 0) {
        $this->merk = $merk;
        $this->version = $version;
        $this->ukuranLayar = $ukuranLayar;
        $this->harga = $harga;
    }

    //method f
    abstract public function userData();
    public function get_merk(){
        return $this->merk;
    }

    public function inputData(){
        return "Welcome To Database";
    }

    public function adminData(){
        return "Welcome can  help you";
    }
}

class Xiaomi extends Handphone{
    function userData()
    {
        return "in the way to die user ". parent::get_merk();
    }
}

class Oppo extends Handphone{
    function userData(){
        return "in the way to die user oppo ". parent::get_merk();
    }
}