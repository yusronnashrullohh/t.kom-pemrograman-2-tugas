<?php

interface CetakAlatMakan{
    public function getInfoAlatMakan();
}

abstract class AlatMakan {
    private $merk;
    private $warna;
    private $harga;
    private $diskon;

    public function __construct($merk = "merk", $warna = "warna", $harga = 0, $diskon = 0){
        $this->merk = $merk;
        $this->warna = $warna;
        $this->harga = $harga;
        $this->diskon = $diskon;
    }
    public function setMerk($merk){
        $this->merk = $merk;
    }
    public function getMerk(){
        return $this->merk;
    }
    public function setWarna($warna){
        $this->warna = $warna;
    }
    public function getWarna(){
        return $this->warna;
    }
    public function setHarga($harga){
        $this->harga = $harga;
    }
    public function getHarga(){
        return $this->harga;
    }
    public function setDiskon($diskon){
        $this->diskon = $diskon;
    }
    public function getDiskon(){
        return $this->diskon;
    }
    abstract public function getInfoAlatMakan();

    public function getInfo(){
        $str = "{$this->merk} | (Rp. {$this->harga}) (Rp. {$this->diskon})";
        return $str;
    }
}

class Sendok extends AlatMakan implements CetakAlatMakan {
    public $ukuran;
    public function __construct($merk = "merk", $warna = "warna", $harga = 0, $diskon = 0, $ukuran = "ukuran"){
        parent:: __construct($merk, $warna, $harga, $diskon);
        $this->ukuran = $ukuran;
    }
    public function getInfoAlatMakan(){
        $str = "Sendok : " . $this->getInfo() . "- {$this->ukuran}";
        return $str;
    }
}
class Sumpit extends AlatMakan implements CetakAlatMakan {
    public $bentuk;
    public function __construct($merk = "merk", $warna = "warna", $harga = 0, $diskon = 0, $bentuk = "bentuk"){
        parent:: __construct($merk, $warna, $harga, $diskon);
        $this->bentuk = $bentuk;
    }
    public function getInfoAlatMakan(){
        $str = "Sumpit : " . $this->getInfo() . "- {$this->bentuk}";
        return $str;
    }
}

class CetakInfoAlatMakan {
    public $daftarAlatMakan = Array();

    public function tambahAlatMakan(AlatMakan $alatMakan){
        $this->daftarAlatMakan[] = $alatMakan; 
    }

    public function cetak(){
        $str = "Daftar Alat Makan : <br>";
        foreach ($this->daftarAlatMakan as $p) {
            $str .= "- {$p->getInfoAlatMakan()} <br>";
        }
        return $str;
    }
}

$alatMakan1 = new Sendok("Vicenza", "Merah", 50000, 20, "Kecil");
$alatMakan2 = new Sumpit("Stainless Steel", "Kuning", 70000, 40, "Panjang");


$cetakAlatMakan = new CetakInfoAlatMakan();
$cetakAlatMakan->tambahAlatMakan($alatMakan1);
$cetakAlatMakan->tambahAlatMakan($alatMakan2);

echo $cetakAlatMakan->cetak();