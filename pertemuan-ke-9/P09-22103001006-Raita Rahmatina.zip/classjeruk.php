<?php

namespace Buah;

class Jeruk {
    public function getWarna() {
        return "oranye";
    }
}