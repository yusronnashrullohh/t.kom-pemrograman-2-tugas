<?php

namespace Buah;

class Mangga {
    public function getWarna() {
        return "hijau";
    }
}