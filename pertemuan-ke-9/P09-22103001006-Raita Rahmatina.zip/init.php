<?php

// Fungsi untuk memuat kelas secara otomatis
spl_autoload_register(function ($class_name) {
    // Konversi namespace menjadi path file
    $file_name = str_replace('\\', '/', $class_name) . '.php';
    // Cek apakah file kelas ada dan muat
    if (file_exists($file_name)) {
        require_once $file_name;
    }
});