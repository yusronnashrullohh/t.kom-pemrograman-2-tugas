<?php

namespace Buah;

class Apel {
    public function getWarna() {
        return "merah";
    }
}