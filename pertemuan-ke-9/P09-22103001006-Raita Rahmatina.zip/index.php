<?php

require_once 'init.php';

use Buah\Apel;
use Buah\Jeruk;
use Buah\Mangga;

$apel = new Apel();
$jeruk = new Jeruk();
$mangga = new Mangga();

echo "Warna Apel: " . $apel->getWarna() . "<br>";
echo "Warna Jeruk: " . $jeruk->getWarna() . "<br>";
echo "Warna Mangga: " . $mangga->getWarna() . "<br>";