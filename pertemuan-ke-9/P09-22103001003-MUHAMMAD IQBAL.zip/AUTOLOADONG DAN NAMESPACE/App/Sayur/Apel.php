<?php

namespace App\Sayur;

class Apel
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}