<?php

namespace App\Sayur;

class Jeruk
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}