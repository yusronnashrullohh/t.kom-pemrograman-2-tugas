<?php

namespace App\Sayur;

class Mangga
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}
