<?php
// spl_autoload_register(
//     function ($class) {
//         require_once __DIR__ . '/Buah/' . $class . '.php';
//     }
// );

require_once 'Buah/Apel.php';
require_once 'Buah/Jeruk.php';
require_once 'Buah/Mangga.php';
require_once 'Sayur/Apel.php';
require_once 'Sayur/Jeruk.php';
require_once 'Sayur/Mangga.php';
