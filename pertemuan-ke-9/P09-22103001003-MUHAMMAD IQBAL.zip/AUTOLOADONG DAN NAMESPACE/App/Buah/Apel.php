<?php

namespace App\Buah;

class Apel
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}