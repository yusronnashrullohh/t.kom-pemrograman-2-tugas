<?php

namespace App\Buah;

class Jeruk
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}