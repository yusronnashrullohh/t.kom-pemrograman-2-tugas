<?php

namespace App\Buah;

class Mangga
{
    public function __construct()
    {
        echo "ini adalah berasal dari" . __CLASS__;
    }
}
