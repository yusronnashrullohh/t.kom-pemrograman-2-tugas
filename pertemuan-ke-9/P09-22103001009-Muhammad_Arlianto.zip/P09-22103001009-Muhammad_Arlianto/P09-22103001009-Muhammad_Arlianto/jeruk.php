<?php 
namespace Buah;

class Jeruk {
    private $warna;
    private $rasa;
    
    public function __construct($warna, $rasa) {
        $this->warna = $warna;
        $this->rasa = $rasa;
    }
    
    public function kupas() {
        echo "Mengupas jeruk " . $this->warna . " dengan rasa " . $this->rasa;
    }
}
?>