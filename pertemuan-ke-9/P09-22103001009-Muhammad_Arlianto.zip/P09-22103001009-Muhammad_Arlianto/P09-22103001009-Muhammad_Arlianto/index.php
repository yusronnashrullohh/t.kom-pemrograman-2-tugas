<?php 
require_once 'init.php';

use Buah\Apel;
use Buah\Jeruk;
use Buah\Mangga;

$apel = new Apel("merah", "manis");
$jeruk = new Jeruk("oranye", "asam");
$mangga = new Mangga("hijau", "manis");

$apel->makan();
echo "<br>";
$jeruk->kupas();
echo "<br>";
$mangga->potong();

?>