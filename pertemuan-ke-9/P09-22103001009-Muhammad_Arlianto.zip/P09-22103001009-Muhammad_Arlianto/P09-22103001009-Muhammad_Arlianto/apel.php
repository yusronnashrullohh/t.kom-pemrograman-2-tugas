<?php 
namespace Buah;

class Apel {
    private $warna;
    private $rasa;
    
    public function __construct($warna, $rasa) {
        $this->warna = $warna;
        $this->rasa = $rasa;
    }
    
    public function makan() {
        echo "Menggigit apel " . $this->warna . " dengan rasa " . $this->rasa;
    }
}
?>